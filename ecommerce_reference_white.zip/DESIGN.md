---
name: Warm Editorial
colors:
  surface: '#fcf8fb'
  surface-dim: '#dcd9dc'
  surface-bright: '#fcf8fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f5'
  surface-container: '#f0edef'
  surface-container-high: '#eae7ea'
  surface-container-highest: '#e4e2e4'
  on-surface: '#1b1b1d'
  on-surface-variant: '#424845'
  inverse-surface: '#303032'
  inverse-on-surface: '#f3f0f2'
  outline: '#727875'
  outline-variant: '#c2c8c4'
  surface-tint: '#4e635a'
  primary: '#4e635a'
  on-primary: '#ffffff'
  primary-container: '#8da399'
  on-primary-container: '#263932'
  inverse-primary: '#b5ccc1'
  secondary: '#7d562d'
  on-secondary: '#ffffff'
  secondary-container: '#ffca98'
  on-secondary-container: '#7a532a'
  tertiary: '#5e5f5d'
  on-tertiary: '#ffffff'
  tertiary-container: '#9e9e9c'
  on-tertiary-container: '#343634'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e8dd'
  primary-fixed-dim: '#b5ccc1'
  on-primary-fixed: '#0b1f18'
  on-primary-fixed-variant: '#374b43'
  secondary-fixed: '#ffdcbd'
  secondary-fixed-dim: '#f0bd8b'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#623f18'
  tertiary-fixed: '#e3e2e0'
  tertiary-fixed-dim: '#c7c6c4'
  on-tertiary-fixed: '#1a1c1a'
  on-tertiary-fixed-variant: '#464745'
  background: '#fcf8fb'
  on-background: '#1b1b1d'
  surface-variant: '#e4e2e4'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
---

## Brand & Style
This design system embodies a "Warm Editorial" aesthetic, blending the intellectual rigor of a high-end publication with the approachability of a lifestyle brand. It targets a discerning audience that values clarity, mindfulness, and intentionality. The emotional response should be one of "Aetheric Precision"—a feeling of being focused yet calm, facilitated by a UI that breathes through generous whitespace and soft, organic transitions.

The style is a hybrid of **Minimalism** and **Tactile Editorial**. It utilizes high-quality serif typography to establish authority and paired-back UI elements to ensure usability. The use of asymmetric layouts and soft background "blobs" breaks the rigidity of standard digital grids, creating a more human and fluid experience.

## Colors
The palette is rooted in a soft, organic base to reduce eye strain and evoke a sense of heritage and quality.

*   **Surface (Base):** #FAF9F6 (Warm Cream). This is the primary background color for all screens.
*   **Ink (Primary Text):** #1D1D1F (Deep Charcoal). Provides high legibility while remaining softer than pure black.
*   **Accent 1 (Sage):** #8DA399. Used for primary actions, success states, and calm highlights.
*   **Accent 2 (Amber):** #D4A373. Used for secondary call-to-actions, notifications, or to denote warmth and craftsmanship.
*   **Decorative:** Soft, low-opacity blurs of the accent colors should be used in the background to create depth without distracting from content.

## Typography
The typography is the cornerstone of the editorial feel. **Playfair Display** provides a sophisticated, high-contrast serif look for headings, while **Inter** ensures that functional text and long-form body copy remain highly legible and modern.

Maintain a strict vertical rhythm. Headlines should always have generous bottom margins. For "Display" styles, use slight negative letter-spacing to tighten the visual impact of large titles. Labels should be set in uppercase with increased tracking to distinguish them from body copy.

## Layout & Spacing
The design system employs an **Asymmetric Fluid Grid**. While content generally adheres to a 12-column structure on desktop, key elements (like hero images or pull quotes) should intentionally break the grid or be offset to create an editorial, magazine-like flow.

*   **Desktop:** 12-column grid, 64px outer margins, 24px gutters.
*   **Mobile:** 4-column grid, 20px outer margins, 16px gutters.
*   **White Space:** Use "Macro-spacing" (80px+) between major sections to emphasize the "Aetheric" quality of the brand.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows**. Avoid heavy, dark dropshadows.

*   **Surfaces:** Use subtle shifts in background color (e.g., a slightly darker cream or a very pale Sage tint) to distinguish containers.
*   **Shadows:** Shadows should be extremely diffused (30px+ blur) with very low opacity (5-8%) and tinted with the Primary Charcoal color.
*   **Organic Depth:** Background blurs (glassmorphism) may be used on navigation bars, but with a high "warmth" factor to maintain the creamy aesthetic. Use large, soft-edged organic shapes (blobs) behind primary content to lift it visually without hard borders.

## Shapes
The shape language is soft and approachable. Following the "ROUND_TWELVE" logic, the standard radius for components is 0.5rem (8px), which scales up to 1.5rem (24px) for large cards and containers.

Images should feature slightly larger radii than buttons to emphasize a "soft-frame" editorial look. Interactive elements like toggle switches or pill-labels may use full rounding (capsule shape) to differentiate them from structural layout elements.

## Components
Consistent application of the "Warm Editorial" style across components:

*   **Buttons:** Primary buttons use a solid Sage Green background with white text. Secondary buttons use a fine 1px Charcoal border with no fill. Always use the standard 8px corner radius.
*   **Cards:** Use a very subtle 1px border (#E5E4E0) or a soft ambient shadow to define card boundaries. Background should be pure white (#FFFFFF) against the off-white page background.
*   **Input Fields:** Minimalist design with only a bottom border in Charcoal, or a very light-tinted Sage background with 8px rounding.
*   **Chips/Labels:** Small, capsule-shaped elements using the Amber accent with low opacity (10-15%) for the background and high-contrast text.
*   **Lists:** High whitespace between list items, separated by thin, elegant horizontal rules (#E5E4E0).
*   **Photography:** Images should be naturally lit, slightly desaturated, and use "soft-focus" or organic masking where appropriate to match the background blurs.