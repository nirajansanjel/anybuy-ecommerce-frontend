---
name: Midnight Editorial
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c1c6d7'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8b90a0'
  outline-variant: '#414755'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e69'
  primary-container: '#4b8eff'
  on-primary-container: '#00285c'
  inverse-primary: '#005bc1'
  secondary: '#c6c6c8'
  on-secondary: '#2f3132'
  secondary-container: '#454749'
  on-secondary-container: '#b4b5b7'
  tertiary: '#c6c6cb'
  on-tertiary: '#2f3034'
  tertiary-container: '#909095'
  on-tertiary-container: '#282a2e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#e2e2e4'
  secondary-fixed-dim: '#c6c6c8'
  on-secondary-fixed: '#1a1c1d'
  on-secondary-fixed-variant: '#454749'
  tertiary-fixed: '#e3e2e7'
  tertiary-fixed-dim: '#c6c6cb'
  on-tertiary-fixed: '#1a1b1f'
  on-tertiary-fixed-variant: '#46464b'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-xl:
    fontFamily: Syne
    fontSize: 80px
    fontWeight: '800'
    lineHeight: 88px
    letterSpacing: -0.04em
  display-xl-mobile:
    fontFamily: Syne
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Syne
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  bento-gap: 16px
---

## Brand & Style

This design system is built for a high-end, futuristic e-commerce experience. The brand personality is immersive and authoritative, blending the precision of technical hardware with the sophistication of luxury editorial magazines. The aesthetic targets a tech-savvy audience that values craftsmanship and exclusivity.

The visual style is a hybrid of **Glassmorphism** and **Bento-grid** layouts. It utilizes deep layering, wide-aperture background blurs, and "light-leak" ambient glows to create a sense of three-dimensional space. Layouts should feel intentional and asymmetric, breaking standard vertical scrolls with horizontal sections and varied grid spans to maintain an editorial flow.

## Colors

The palette is rooted in deep obsidian tones to allow product imagery and the accent color to vibrate. 

- **Neutral Base:** `#0a0a0a` is the foundation for all surfaces. Use varying opacities of white overlays (1% to 4%) to create secondary and tertiary surface elevations.
- **Primary Accent:** Electric Blue (`#007aff`) is reserved for critical interactions, status indicators, and localized "glow" effects. It should never be used for large surface areas, only for highlights and light-source effects.
- **Typography:** Use `#f5f5f7` (Off-white) for primary headers to reduce ocular strain against the dark background. Use Silver/Grey (`#8e8e93`) for secondary metadata and captions.

## Typography

The typography strategy relies on the tension between the expressive, avant-garde forms of **Syne** and the hyper-functional, technical clarity of **Geist**. 

- **Headlines:** Use Syne for all display and headline levels. Large sizes should utilize the "Extra Bold" weight with tight tracking to create a high-impact, editorial feel.
- **Body:** Geist provides a modern, developer-adjacent aesthetic that reinforces the "high-end tech" narrative. 
- **Metadata:** Use JetBrains Mono in all-caps for technical specifications, product SKUs, and labels to evoke a sense of precision and "under the hood" engineering.

## Layout & Spacing

The design system utilizes a **Bento-grid** philosophy nested within a 12-column fluid container. Layouts are characterized by modules of varying sizes that "snap" together.

- **Desktop:** A 1440px max-width container with 64px side margins. Utilize asymmetric column spans (e.g., a 7-column image next to a 4-column text block with 1-column offset) to create editorial interest.
- **Bento Modules:** Use a consistent 16px or 24px gap between grid cards. Cards should vary in height to create a "masonry" feel while maintaining strict horizontal alignment on key rows.
- **Negative Space:** Generous vertical padding (120px+) between major sections is required to maintain a premium, uncrowded feel.

## Elevation & Depth

Depth is achieved through **Glassmorphism** and light simulation rather than traditional drop shadows.

- **Surface Treatment:** Cards use a semi-transparent background (e.g., `rgba(255, 255, 255, 0.03)`) with a `20px` backdrop-blur. 
- **Glow Borders:** Elements are defined by a 1px solid stroke. The top and left strokes should be slightly brighter (`rgba(255, 255, 255, 0.1)`) than the bottom and right, simulating a top-down light source.
- **Ambient Lighting:** Place large, low-opacity radial gradients (Electric Blue) behind primary product imagery to create a "halo" effect that bleeds into the dark canvas.
- **Interaction Depth:** On hover, card opacities should increase slightly, and the inner stroke should transition to a subtle Electric Blue glow.

## Shapes

The shape language is sophisticated and controlled. We avoid fully circular "pill" shapes for primary containers to maintain a serious, architectural tone.

- **Cards & Modules:** Use `1rem` (16px) for standard bento cards.
- **Buttons:** Use `0.5rem` (8px) for a sharper, more technical appearance.
- **Small Elements:** Tooltips and tags use `0.25rem` (4px).
- **Interactive States:** Maintain consistent radii across nested elements (e.g., an image inside a card should have a radius that complements the outer container).

## Components

- **Buttons:** Primary buttons are filled with Electric Blue with white text. Secondary buttons are "ghost" style with the 1px light-stroke and a backdrop blur. Use high-contrast hover states where the background "lights up."
- **Bento Cards:** The core container. Must include the 1px glowing border and backdrop blur. Text within should follow a strict hierarchy: Mono-label at top, Syne headline, then Geist body text.
- **Inputs:** Minimalist bottom-border only or very subtle 1px frames. Focus states should trigger a soft Electric Blue outer glow (bloom effect).
- **Chips/Tags:** Monospaced text inside small, high-contrast borders. Used for technical specs (e.g., "5NM CHIP", "120HZ").
- **Product Tiles:** Focus on edge-to-edge photography with text overlays. Use a gradient mask at the bottom of images to ensure legibility of white text.
- **Navigation:** A fixed "floating" header with heavy backdrop blur and a 1px bottom border. Links should use Geist Medium with a subtle character-spacing increase.